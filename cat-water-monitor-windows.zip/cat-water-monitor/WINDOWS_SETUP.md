# Windows PC 接续指南

目标机器：用户现有 Windows 10、RTX 4060、i7-9700KF；摄像头仍使用 C920。

**本迁移包在 Mac 上准备。已完成 Mac 回归测试，但尚未在用户 Windows PC 上安装或验证 RTX 4060 / C920。** 当前聊天仍连接 Mac；看到聊天记录不等于已经连接 Windows 文件系统。

## 1. 将文件放到 PC

解压 `cat-water-monitor-windows.zip` 到固定位置，例如 `D:\Projects\cat-water-monitor`。请进入真正包含 `pyproject.toml`、`config.windows.json` 的目录，不要在 ZIP 内直接运行脚本。

此包包含源码和已下载的 YOLO26 nano 分割权重。不包含 Mac 的 `.venv`；必须在 Windows 建立独立运行环境。两只猫尚未登记毛色样本，ROI 尚未配置，也没有真实事件数据。

## 2. 安装并验证环境

先安装 Python 3.12（包含 Python launcher），确认 NVIDIA 驱动已安装。然后双击 `scripts\install_windows.bat`。

脚本会在项目自己的 `.venv` 中：

1. 安装官方 CUDA 12.8 索引提供的 PyTorch 与 torchvision。
2. 安装项目依赖和测试工具。
3. 检查 CUDA 是否可用，并实际在 GPU 上执行矩阵运算。
4. 用配置 `device="0"` 加载 YOLO26 并做一次空白帧推理。
5. 执行测试；成功后将 Windows 的具体依赖版本写入 `data\windows-installed.txt`。

GPU 不可用时脚本会报错停止，不能把安装成功当作已使用 4060。若 CUDA 12.8 对应的驱动要求不满足，先在 PC 上检查 `nvidia-smi`，再按 [PyTorch 官方安装选择器](https://pytorch.org/get-started/locally/) 选择合适的构建或更新驱动，不要盲目反复重装。

Windows 安装脚本使用 pip 单独解析适配 Windows / CUDA 的依赖，**不声称与 Mac 的 uv.lock 形成同一个已验证 GPU 环境**。不要在 CUDA 安装后直接执行普通 `uv sync` 来覆盖 GPU 软件包；待 PC 端验证后再固化专用 GPU 锁定方案。

可手动在项目目录终端检查：

```powershell
.venv\Scripts\python.exe -m catwatch --config config.windows.json doctor --model
```

应显示 `CUDA available: True`、RTX 4060、`GPU computation: PASS` 和 `inference: PASS`。单次通过不代表长期稳定或功耗合格。

## 3. 接 C920、框选饮水区

连接 C920，先固定在饮水机旁。双击 `scripts\setup_camera_windows.bat`，在预览中拖动区域，回车保存。Esc 取消。

`config.windows.json` 中 `source=0` 只是默认编号，必须确认画面确为 C920。如无画面，检查 USB、Windows 相机隐私设置是否允许桌面应用、是否被视频会议程序占用，再按实际设备尝试其他编号。

## 4. 校准冲冲和茉莉

打开项目目录的 PowerShell。每张照片只拍一只猫，各拍 5–10 张不同姿势。以下只示范一个文件名，请每次换成 02、03 等，以免覆盖。

```powershell
.venv\Scripts\python.exe -m catwatch --config config.windows.json snapshot data/calibration/chong_01.jpg
.venv\Scripts\python.exe -m catwatch --config config.windows.json snapshot data/calibration/moli_01.jpg
```

完成至少三张/猫后：

```powershell
.venv\Scripts\python.exe -m catwatch --config config.windows.json enroll 冲冲 "data/calibration/chong_*.jpg"
.venv\Scripts\python.exe -m catwatch --config config.windows.json enroll 茉莉 "data/calibration/moli_*.jpg"
```

程序已支持自行展开通配符。未完成双猫样本登记时，采集可以运行，但身份为 unknown。

## 5. 试跑与看板

分别双击：

- `scripts\monitor_windows.bat`：GPU 采集与预览；Q 或 Ctrl+C 停止。
- `scripts\dashboard_windows.bat`：生成独立模拟库并打开看板服务。浏览器访问终端显示的 `http://127.0.0.1:8501`；侧栏可以切换模拟数据。

默认 2 次/秒推理、640 输入，保持第一阶段负载设定。记录的是区域停留候选事件，不是确认喝水或毫升数。

先做 10 分钟现场观察，再做 2 小时、24 小时测试。Windows 自动启动、任务守护和电源设置在实测稳定后再配置；此包不会自动修改系统设置。

## 给 PC 端 Codex 的接续信息

在 PC 的 Codex 中打开解压目录后，告诉它：

> 继续家庭双猫饮水监控项目。Windows 10 / RTX 4060 / i7-9700KF，现有 C920。先阅读 WINDOWS_SETUP.md 和 VALIDATION.md，确认当前确实是 Windows 环境，再验证 Python 3.12、NVIDIA 驱动、CUDA PyTorch 与 YOLO26n-seg。用 config.windows.json；先框选饮水区，再采集冲冲/茉莉样本。不要把模拟事件当成实测，也不要先买硬件。
