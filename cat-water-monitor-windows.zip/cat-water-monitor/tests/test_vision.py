import cv2
import numpy as np
from catwatch.vision import descriptor, identify, in_zone


def color(bgr):
    return np.full((40, 40, 3), bgr, dtype=np.uint8)


def test_mask_excludes_background_and_profiles_separate_coats():
    mask = np.ones((40, 40), dtype=np.uint8)
    a = descriptor(color((20,20,20)), mask)
    b = descriptor(color((230,230,230)), mask)
    profiles = {"冲冲":[a.tolist()]*3, "茉莉":[b.tolist()]*3}
    assert identify(a, profiles)[0] == "冲冲"
    assert identify(b, profiles)[0] == "茉莉"
    assert identify(a, {"冲冲":[a.tolist()]})[0] == "unknown"
    assert identify(a, {"冲冲":[a.tolist()], "茉莉":[a.tolist()]})[0] == "unknown"
    mask[:, :20] = 0
    image = color((20,20,20))
    image[:, :20] = (230,230,230)
    assert np.allclose(descriptor(image, mask), a)


def test_zone_fraction_and_tiny_mask():
    mask = np.zeros((100,100), np.uint8)
    mask[30:70,30:70] = 1
    assert in_zone(mask, [.3,.3,.7,.7], .5)
    assert not in_zone(mask, [0,0,.1,.1], .1)
    assert descriptor(color((0,0,0)), np.zeros((40,40), np.uint8)) is None
