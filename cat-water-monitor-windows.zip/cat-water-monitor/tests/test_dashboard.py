import json
from streamlit.testing.v1 import AppTest
from catwatch.core import ROOT, Store, VisitEngine


def test_dashboard_stats_and_review(tmp_path, monkeypatch):
    import time
    config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    config["db"] = str(tmp_path / "events.db")
    config["status"] = str(tmp_path / "status.json")
    path = tmp_path / "config.json"
    path.write_text(json.dumps(config))
    store = Store(config["db"])
    e = VisitEngine("test")
    start = time.time() - 10
    for i in range(13):
        e.tick(start + i*.5, ["冲冲"])
    store.save(e.finish())
    monkeypatch.setenv("CATWATCH_CONFIG", str(path))
    app = AppTest.from_file(str(ROOT / "dashboard.py"), default_timeout=30).run()
    assert not app.exception
    assert app.metric[0].value == "1"
    app.selectbox(key="review_result").select("confirmed_drinking")
    app.selectbox(key="review_cat").select("茉莉")
    app.button[0].click().run()
    assert not app.exception
    assert store.conn.execute("SELECT review,reviewed_cat FROM events").fetchone() == ("confirmed_drinking", "茉莉")
    store.close()
