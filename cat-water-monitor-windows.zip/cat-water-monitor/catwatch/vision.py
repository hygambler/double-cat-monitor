"""YOLO cat foreground masks + calibrated coarse coat-color histograms."""
import json
import os
from pathlib import Path
import cv2
import numpy as np


def descriptor(frame, mask):
    # LAB keeps achromatic dark/white coat information as well as color.
    if np.count_nonzero(mask) < 200:
        return None
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    hist = cv2.calcHist([lab], [0, 1, 2], mask.astype(np.uint8), [8, 8, 8], [0, 256] * 3)
    return (hist.ravel() / max(float(hist.sum()), 1.)).astype(np.float32)


def identify(feature, profiles, max_distance=.55, margin=.12):
    if feature is None or len(profiles) != 2:
        return "unknown", None
    scores = sorted((min(float(cv2.compareHist(feature, np.array(sample, np.float32),
                                             cv2.HISTCMP_BHATTACHARYYA)) for sample in samples), cat)
                    for cat, samples in profiles.items() if samples)
    if len(scores) != 2:
        return "unknown", None
    (d, cat), (second, _) = scores
    return (cat if d <= max_distance and second - d >= margin else "unknown"), d


class Detector:
    def __init__(self, c):
        os.environ.setdefault("YOLO_CONFIG_DIR", str(Path(c["model"]).parent / "ultralytics"))
        os.environ.setdefault("MPLCONFIGDIR", str(Path(c["model"]).parent / "matplotlib"))
        from ultralytics import YOLO
        self.c = c
        self.model = YOLO(c["model"])
        if self.model.task != "segment":
            raise ValueError("Use a segmentation model, e.g. yolo26n-seg.pt")
        self.cat_class = next(int(k) for k, name in self.model.names.items() if name == "cat")

    def detect(self, frame):
        r = self.model.predict(frame, classes=[self.cat_class], conf=self.c["confidence"],
                               imgsz=self.c["imgsz"], device=self.c["device"],
                               retina_masks=True, verbose=False)[0]
        if r.masks is None:
            return []
        h, w = frame.shape[:2]
        result = []
        for box, mask in zip(r.boxes.xyxy.cpu().numpy(), r.masks.data.cpu().numpy()):
            mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST) > .5
            result.append((box.astype(int), mask.astype(np.uint8)))
        return result


def load_profiles(path, cats):
    p = Path(path)
    if not p.exists():
        return {}
    profiles = json.loads(p.read_text(encoding="utf-8"))
    if set(profiles) != set(cats):
        return {}
    for samples in profiles.values():
        for sample in samples:
            a = np.asarray(sample)
            if a.shape != (512,) or not np.isfinite(a).all() or (a < 0).any() or not np.isclose(a.sum(), 1, atol=.01):
                raise ValueError("Invalid coat profile; re-enroll")
    return profiles


def in_zone(mask, zone, threshold):
    h, w = mask.shape
    x1, y1, x2, y2 = [int(v * size) for v, size in zip(zone, (w, h, w, h))]
    return np.count_nonzero(mask[y1:y2, x1:x2]) / max(1, np.count_nonzero(mask)) >= threshold
