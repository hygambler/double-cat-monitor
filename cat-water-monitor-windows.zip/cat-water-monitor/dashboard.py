"""Read-only statistics; deliberate form submissions save manual reviews."""
from datetime import datetime, timedelta
import io
import json
import os
from pathlib import Path
import sqlite3
import time
from zoneinfo import ZoneInfo

import pandas as pd
import streamlit as st
from catwatch.core import ROOT, load_config

st.set_page_config(page_title="冲冲与茉莉 · 饮水区观察", page_icon="🐈", layout="wide")
c = load_config(os.environ.get("CATWATCH_CONFIG"))
st.title("🐈 家庭双猫 · 饮水区观察")
st.caption("候选事件 = 饮水区域停留；不代表确认喝水，不估计毫升数。未记录到事件也可能是断流、遮挡或漏检。")
is_demo = st.sidebar.checkbox("查看演示数据（模拟）", value=False)
path = ROOT / "data/demo.sqlite3" if is_demo else Path(c["db"])
if is_demo:
    st.warning("当前显示模拟事件，用于检查界面，不是冲冲和茉莉的实测记录。")
else:
    status_path = Path(c["status"])
    if status_path.exists():
        try:
            status = json.loads(status_path.read_text(encoding="utf-8"))
            age = time.time() - status["updated"]
            st.info(f"采集状态：{status['state']} · 心跳 {age:.0f} 秒前 · 本次处理 {status.get('frames', 0)} 帧")
            if age > 15:
                st.warning("心跳已过期，采集可能已停止。此时没有事件不能解释为猫没有喝水。")
            st.caption(f"最近推理耗时中位数：{status.get('inference_ms_p50', '—')} ms；"
                       f"P95：{status.get('inference_ms_p95', '—')} ms（仅进程内最近样本）")
            if status.get("replay"):
                st.warning("采集端正在/曾在回放视频；请确保回放使用独立数据库。")
        except (ValueError, KeyError):
            st.warning("状态文件暂时无法读取。")
    else:
        st.info("采集尚未启动。可以先在侧栏查看模拟数据。")
if not path.exists():
    st.info("数据库尚未生成。运行采集程序，或执行 python -m catwatch demo 后选择演示数据。")
    st.stop()

TZ = ZoneInfo("Asia/Shanghai")
days = st.sidebar.selectbox("查看最近天数", [1, 7, 30], index=1)
start_day = datetime.now(TZ).date() - timedelta(days=days - 1)
start_ts = datetime.combine(start_day, datetime.min.time(), TZ).timestamp()
with sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10) as conn:
    df = pd.read_sql_query("SELECT * FROM events WHERE start_ts >= ? ORDER BY start_ts DESC", conn, params=[start_ts])
if df.empty:
    st.info("所选时段没有候选事件。请同时检查采集状态。")
    st.stop()
df["归属"] = df["reviewed_cat"].fillna(df["cat"])
df["开始"] = pd.to_datetime(df.start_ts, unit="s", utc=True).dt.tz_convert(TZ)
df["日期"] = df["开始"].dt.strftime("%Y-%m-%d")
df["区域停留秒"] = (df.end_ts - df.start_ts).round(1)
cols = st.columns(3)
cols[0].metric("候选事件", len(df))
cols[1].metric("人工确认喝水", int((df.review == "confirmed_drinking").sum()))
cols[2].metric("身份未知（复核后）", int((df["归属"] == "unknown").sum()))
st.caption("按事件开始日期归档。区域停留秒含短暂漏检；observed_seconds 仅累计相邻有效采样间隔，不是舔水时长。")
counts = df.groupby(["日期", "归属"]).size().unstack(fill_value=0)
st.bar_chart(counts)
st.dataframe(df[["id", "开始", "cat", "归属", "区域停留秒", "observed_seconds", "ambiguous", "review", "end_reason"]], hide_index=True)
st.download_button("导出当前事件 CSV", df.to_csv(index=False).encode("utf-8-sig"), "water-zone-events.csv", "text/csv")
with st.expander("人工复核 / 修正身份"):
    st.caption("请结合现场观察或独立拍摄的测试视频判断；第一版不保存家庭视频或截图。")
    with st.form("review"):
        event_id = st.selectbox("事件编号", df.id.tolist(), key="review_event")
        review = st.selectbox("复核结果", ["pending", "confirmed_drinking", "rejected", "uncertain"], key="review_result",
                              format_func=lambda x: {"pending":"待复核", "confirmed_drinking":"确认喝水", "rejected":"并非喝水", "uncertain":"无法判断"}[x])
        corrected = st.selectbox("身份归属", ["保留模型结果", *c["cats"], "unknown"], key="review_cat")
        if st.form_submit_button("保存复核"):
            with sqlite3.connect(path, timeout=10) as conn:
                conn.execute("UPDATE events SET review=?, reviewed_cat=? WHERE id=?",
                             (review, None if corrected == "保留模型结果" else corrected, int(event_id)))
            st.rerun()
st.button("刷新", on_click=lambda: None)
