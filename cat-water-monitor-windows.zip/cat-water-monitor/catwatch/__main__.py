import argparse
from collections import deque
import json
import os
from pathlib import Path
import signal
import time

from .core import ROOT, Store, VisitEngine, load_config


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def source_for(c):
    return os.environ.get("CATWATCH_SOURCE", c["source"])


def setup(c):
    import cv2
    from .capture import open_capture
    cap = open_capture(source_for(c), c)
    try:
        ok, frame = cap.read()
        if not ok:
            raise RuntimeError("无法读取摄像头；检查 USB、相机权限和 source 编号。")
        x, y, w, h = cv2.selectROI("Water zone - ENTER confirm / ESC cancel", frame, False)
        if w == 0 or h == 0:
            print("已取消，没有修改配置。")
            return None
        height, width = frame.shape[:2]
        return [x / width, y / height, (x + w) / width, (y + h) / height]
    finally:
        cap.release()
        cv2.destroyAllWindows()


def expand_images(patterns):
    # CMD and PowerShell do not expand globs for Python scripts as Unix shells do.
    import glob
    paths = []
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if not matches:
            raise FileNotFoundError(f"没有匹配到照片：{pattern}")
        paths.extend(matches)
    return list(dict.fromkeys(paths))


def doctor(c, check_model=False):
    import platform
    import torch
    import cv2
    print(f"System: {platform.system()} | Python: {platform.python_version()}")
    print(f"PyTorch: {torch.__version__} | CUDA build: {torch.version.cuda}")
    available = torch.cuda.is_available()
    print(f"CUDA available: {available}")
    if available:
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        x = torch.ones((32, 32), device="cuda:0")
        result = x @ x
        torch.cuda.synchronize()
        assert result[0, 0].item() == 32
        print("GPU computation: PASS")
    print(f"Configured device: {c['device']} | OpenCV: {cv2.__version__}")
    if str(c["device"]) in ("0", "cuda", "cuda:0") and not available:
        raise RuntimeError("配置要求 GPU，但 CUDA 不可用；请检查 NVIDIA 驱动及 PyTorch GPU 安装。")
    if check_model:
        import numpy as np
        from .vision import Detector
        d = Detector(c)
        d.detect(np.zeros((480, 640, 3), np.uint8))
        print(f"YOLO model: {Path(c['model']).name} | task: {d.model.task} | inference: PASS")


def enroll(c, cat, images):
    import cv2
    from .vision import Detector, descriptor
    if cat not in c["cats"]:
        raise ValueError("cat must match a configured name")
    detector = Detector(c)
    features = []
    for path in images:
        frame = cv2.imread(path)
        if frame is None:
            raise ValueError(f"Cannot read image: {path}")
        cats = detector.detect(frame)
        if len(cats) != 1:
            raise ValueError(f"Exactly one visible cat required: {path}; detected {len(cats)}")
        feature = descriptor(frame, cats[0][1])
        if feature is None:
            raise ValueError(f"Cat too small: {path}")
        features.append(feature.tolist())
    if len(features) < 3:
        raise ValueError("至少提供 3 张同一只猫的现场照片，建议 5–10 张不同姿势。")
    p = Path(c["profiles"])
    profiles = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    profiles[cat] = features
    atomic_json(p, profiles)
    print(f"已保存 {cat} 的 {len(features)} 个样本。需完成两只猫的校准才会输出名字。")


def demo(c):
    # Generated occupancy observations, explicitly separate from real evidence.
    db = ROOT / "data/demo.sqlite3"
    store = Store(db)
    if store.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]:
        store.close()
        print(f"演示库已存在：{db}（未追加）")
        return
    start = time.time() - 3600
    for i, cat in enumerate([*c["cats"], "unknown"]):
        engine = VisitEngine("DEMO_generated", minimum=3, max_step=1)
        t = start + i * 600
        for j in range(13):
            engine.tick(t + j * .5, [cat])
        for event in engine.tick(t + 10, []):
            store.save(event)
    store.close()
    print(f"生成 3 条模拟事件：{db}；不是摄像头识别结果。")


def run(c, preview=False, video=None, seconds=None):
    import cv2
    import numpy as np
    from .capture import LiveCapture, open_capture
    from .vision import Detector, descriptor, identify, in_zone, load_profiles
    if c["zone"] is None:
        raise ValueError("请先执行 python -m catwatch setup 框选饮水区域。")
    from .process_lock import collector_lock
    lock_path = Path(c["db"]).with_suffix(".lock")
    with collector_lock(lock_path):
        detector = Detector(c)
        profiles = load_profiles(c["profiles"], c["cats"])
        if not profiles:
            print("尚未完成双猫校准，先以 unknown 记录。")
        store = Store(c["db"])
        engine = VisitEngine(c["camera_id"], c["min_observed_seconds"], c["exit_grace_seconds"],
                             c["identity_vote_ratio"], max_step=1.5 / c["inference_fps"])
        stopping = False
        def stop(*_):
            nonlocal stopping
            stopping = True
        old_handlers = {s: signal.signal(s, stop) for s in (signal.SIGINT, signal.SIGTERM)}
        reader = None
        cap = None
        started = time.monotonic()
        epoch = time.time()
        durations = deque(maxlen=120)
        last_seq, frames, saved = -1, 0, 0
        last_heartbeat = 0.
        last_identity = []
        error = None
        try:
            if video:
                cap = open_capture(video, c)
                fps = cap.get(cv2.CAP_PROP_FPS)
                if not cap.isOpened() or not np.isfinite(fps) or fps <= 0:
                    raise RuntimeError("无法读取视频或有效帧率。")
                frame_index, next_sample = 0, 0.
            else:
                reader = LiveCapture(source_for(c), c).start()
            while not stopping and (seconds is None or time.monotonic() - started < seconds):
                frame = None
                now = time.monotonic()
                ts = epoch + now - started
                if video:
                    ok, candidate = cap.read()
                    if not ok:
                        break
                    offset = frame_index / fps
                    frame_index += 1
                    if offset < next_sample:
                        continue
                    next_sample = offset + 1 / c["inference_fps"]
                    ts, frame = epoch + offset, candidate
                else:
                    packet = reader.latest()
                    if packet and packet[0] != last_seq and now - packet[1] < 2:
                        last_seq, _, _, frame = packet
                if frame is None:
                    for event in engine.tick(ts, []):
                        store.save(event)
                        saved += 1
                    last_identity = []
                else:
                    t0 = time.monotonic()
                    detections = detector.detect(frame)
                    identities = []
                    for box, mask in detections:
                        name, _ = identify(descriptor(frame, mask), profiles,
                                           c["identity_max_distance"], c["identity_margin"])
                        if in_zone(mask, c["zone"], c["zone_min_mask_fraction"]):
                            identities.append(name)
                        if preview:
                            x1, y1, x2, y2 = box
                            cv2.rectangle(frame, (x1, y1), (x2, y2), (60, 200, 80), 2)
                            # OpenCV's default font cannot render Chinese names.
                            label = f"cat_{c['cats'].index(name)+1}" if name in c["cats"] else "unknown"
                            cv2.putText(frame, label, (x1, max(20, y1)), 0, .7, (60, 200, 80), 2)
                    for event in engine.tick(ts, identities):
                        store.save(event)
                        saved += 1
                    last_identity = identities
                    frames += 1
                    durations.append(time.monotonic() - t0)
                    if preview:
                        h, w = frame.shape[:2]
                        x1, y1, x2, y2 = [int(v * s) for v, s in zip(c["zone"], (w, h, w, h))]
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 180, 0), 2)
                        cv2.imshow("Catwatch - Q quit", frame)
                        if cv2.waitKey(1) & 255 == ord("q"):
                            break
                if now - last_heartbeat > 2:
                    atomic_json(c["status"], dict(updated=time.time(), state="running" if frame is not None else "no_signal",
                                frames=frames, saved_events=saved, zone_identities=last_identity,
                                active=engine.active is not None, replay=bool(video),
                                inference_ms_p50=round(float(np.median(durations))*1000, 1) if durations else None,
                                inference_ms_p95=round(float(np.percentile(durations,95))*1000, 1) if durations else None))
                    last_heartbeat = now
                if not video:
                    time.sleep(max(0, 1 / c["inference_fps"] - (time.monotonic() - now)))
        except BaseException as exc:
            error = type(exc).__name__
            raise
        finally:
            event = engine.finish("error" if error else "stopped")
            if event:
                store.save(event)
                saved += 1
            if reader:
                reader.close()
            if cap:
                cap.release()
            store.close()
            cv2.destroyAllWindows()
            atomic_json(c["status"], dict(updated=time.time(), state="error" if error else "stopped",
                        error=error, frames=frames, saved_events=saved, replay=bool(video),
                        inference_ms_p50=round(float(np.median(durations))*1000, 1) if durations else None))
            for s, handler in old_handlers.items():
                signal.signal(s, handler)
        print(f"处理 {frames} 帧，保存 {saved} 条候选事件。")


def main():
    p = argparse.ArgumentParser(description="家庭双猫饮水区域监测（本地）")
    p.add_argument("--config", default=str(ROOT / "config.json"))
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("setup", help="摄像头预览并框选饮水区域")
    snap = sub.add_parser("snapshot", help="保存一帧现场校准照片")
    snap.add_argument("output")
    e = sub.add_parser("enroll", help="从单猫现场照片建立毛色样本")
    e.add_argument("cat")
    e.add_argument("images", nargs="+")
    r = sub.add_parser("run", help="运行采集和推理")
    r.add_argument("--preview", action="store_true")
    r.add_argument("--video", help="离线回放；请配独立配置/数据库")
    r.add_argument("--seconds", type=float, help="限时性能试跑")
    d = sub.add_parser("doctor", help="检查环境、GPU 与可选的模型推理")
    d.add_argument("--model", action="store_true")
    sub.add_parser("demo", help="生成独立模拟数据库，不使用摄像头")
    args = p.parse_args()
    c = load_config(args.config)
    if args.command == "setup":
        zone = setup(c)
        if zone:
            path = Path(args.config)
            raw = json.loads(path.read_text(encoding="utf-8"))
            raw["zone"] = zone
            atomic_json(path, raw)
            print(f"已保存饮水区域：{zone}")
    elif args.command == "snapshot":
        import cv2
        from .capture import open_capture
        cap = open_capture(source_for(c), c)
        try:
            ok, frame = cap.read()
            if not ok:
                raise RuntimeError("无法读到摄像头画面。")
            path = Path(args.output)
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                raise FileExistsError("照片已存在，请换一个文件名。")
            if not cv2.imwrite(str(path), frame):
                raise RuntimeError("照片保存失败。")
            print(f"照片已保存：{path}")
        finally:
            cap.release()
    elif args.command == "enroll":
        enroll(c, args.cat, expand_images(args.images))
    elif args.command == "doctor":
        doctor(c, args.model)
    elif args.command == "demo":
        demo(c)
    else:
        run(c, args.preview, args.video, args.seconds)


if __name__ == "__main__":
    main()
